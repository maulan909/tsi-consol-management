<?php
header("Content-type: application/vnd-ms-excel");
header("Content-Disposition: attachment;filename=Moved Package " . date('H:m:s d-m-Y', time()) . ".xls");
?>

<title><?= $title . ' ' . date('H:m:s d-m-Y', time()); ?></title>

<table cellspacing="0" border="1">
    <tr>
        <th>External Order No</th>
        <th>Total Picklist</th>
        <th>Kekurangan</th>
        <th>Lokasi Palet</th>
        <th>Dry/Fresh</th>
        <th>Frozen/Chiller</th>
    </tr>
    <?php foreach ($orders as $order) : ?>
        <?php $picklist = $this->package->getTotalPicklist($order['ca_no']); ?>
        <?php $koli = $this->package->getTotalKoli($order['ca_no']); ?>
        <tr>
            <td><?= $order['ca_no']; ?></td>
            <td><?= $picklist['total']; ?></td>
            <td><?php if (is_int($picklist['total'])) echo $picklist['total'] - $picklist['consol']; ?></td>
            <td><?= $order['palet_no']; ?></td>
            <td><?= $koli['dry']; ?> Koli</td>
            <td><?= $koli['frozen']; ?> Koli</td>
        </tr>
    <?php endforeach; ?>
</table>