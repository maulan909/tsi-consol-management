<!-- Begin Page Content -->
<div class="container-fluid">
    <?= $this->session->flashdata('messages'); ?>
    <!-- Page Heading -->
    <h1 class="h3 mb-4 text-gray-800"><?= $title; ?></h1>

</div>
<!-- /.container-fluid -->